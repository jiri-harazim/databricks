from pyspark.sql import SparkSession
import os

DBUTILS_C = None

def test_connection():
  spark = SparkSession.builder.getOrCreate()
  dbutils = get_dbutils(spark.sparkContext)
  print(dbutils.fs.ls("dbfs:/"))
  print(dbutils.secrets.listScopes())


def init(dbutils):
        if os.getenv('DB_IS_DRIVER') == 'TRUE':
          print('We are running on a driver')
          DBUTILS_C = get_dbutils(SparkSession.builder.getOrCreate())
          print(DBUTILS_C.fs.ls("dbfs:/"))
        else:
                print('We are not running on a driver')
                spark = SparkSession.builder.getOrCreate()
                dbutils = get_dbutils(SparkSession.builder.getOrCreate())
                print(dbutils.fs.ls("dbfs:/"))
                print(dbutils.secrets.listScopes())


def get_dbutils(spark):
    try:
        from pyspark.dbutils import DBUtils
        dbutils = DBUtils(spark)
    except ImportError:
        import IPython
        dbutils = IPython.get_ipython().user_ns["dbutils"]
    return dbutils


def list_dbfs(path):
  spark = SparkSession.builder.getOrCreate()
  print(get_dbutils(spark).fs.ls(path))


#if is_running_in_databricks():
        #from pyspark.dbutils import DBUtils
        #from pyspark.sql import SparkSession
        #spark = SparkSession.builder.appName("Setup Environment").getOrCreate()

        #dbutils = DBUtils(spark)
 #       configuration.host = ""
  #      configuration.api_key['x-api-key'] = dbutils.secrets.get(secret_scope, secret_key)
   #     print("Databricks")