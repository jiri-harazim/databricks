def decorate(what: str):
    result =  what.upper()
    # ToDo: Make it beautiful
    return result # Continue with writing test, wheel, importing to main project